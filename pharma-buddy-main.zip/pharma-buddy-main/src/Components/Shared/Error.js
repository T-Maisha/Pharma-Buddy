import React from "react";

const Error = () => {
  return <div className="flex items-center justify-center text-6xl">u are on wrong site</div>;
};

export default Error;
